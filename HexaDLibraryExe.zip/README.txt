User Name: Admin
Password: Welcome123

Architectural Decisions
1. In Any Organization Library Count will be 1. And Users should be going to Library to borrow books hence Windows Forms Application is Sufficient
2. Since user identity should be validated, users have to provide their SSN/AADHAR/RNVR
3. Both UserID and Password are Case Sensitive
4. Base 64 Encrption is used to Protect data
5. Admin has Privilages to update users and books
6. Admin has to validate user identity during registration
7. To Login admin/user will enter username and password and press login button/press enter in the login page
8. To switch betwen users/Logout press logout button in All Books Page
9. To register user Admin will enter username min (10) max (12) and password min (6)in the users page and click register button
10. To Delete users admin will select user in the grid and press delete button on users page
11. To Add/update books admin will click on Add/Update books after selecting the book row in the grid in all books page
12. To borrow books users will select book in the grid and press borrow button in all books page
13. To Retun books user will select book in the grid and press return button in my books page

Assumptions
1. Admin Will be Logging in with User Name:Admin Password: Welcome123
2. Once Logged in Admin Only Can Register User/Delete User verifying their unique identity provided in the user page by typing user provided user name and user provided password
3. Once Logged in Admin Only Can Add/Update/Delete Books
4. Once Registered Users can Login with User Name (unique identity provided) and Password provided to the admin
5. Once the user is logged in they can borrow/return books to the Library
5. If a person did not return book for a long time admin can reach the user using the unique identity
6. Admin Can Delete users only if all the books are returned by the user
7. Admin Can Delete books only if the books are not available in library and with the user
8. Admin User cannot Borrow books from Library
9. Admin can Add books by clicking on a row and start typing and then clicking Add/Update button
10. User can borrow/Return books by cliking on a row and pressing borrow/Return button
11. Admin Can View All Books and Users Page once logged in where as Users can View My books and All Books Page once logged in


Thoughts
1. Since it is a POC DB connections are not used so as to readily launch the application with Admin User Name:Admin and Password: Welcome123
2. Eventhough it is a POC to protect the data Users.xml and Books.xml files are generated encryptedly in the exe location automatically
3. Eventhough user can login and borrow/return books Admin will be monitoring the borrow/return on the computer shared monitor
